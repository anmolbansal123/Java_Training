package com.flp.ems.util;

public class Validate {
	public static boolean ValidateName() {
		return true;
	}

	public static boolean ValidateKin_Id() {
		return true;
	}

	public static boolean ValidatePhone_no() {
		return true;
	}

	public static boolean Validateemail_id() {
		return true;
	}

	public static boolean Validatedate() {
		return true;
	}
}
