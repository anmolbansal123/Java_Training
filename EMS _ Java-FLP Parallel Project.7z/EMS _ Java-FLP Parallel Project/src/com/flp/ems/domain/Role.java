package com.flp.ems.domain;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Role {
	ArrayList<String> roles = new ArrayList<String>();

	public Role() throws IOException {
		FileReader fr = new FileReader("Roles.txt");
		char ar[] = new char[500];
		fr.read(ar);
		String a = "";
		for (char c : ar) {
			if (c != '\n') {
				a = a + c;
			} // prints the characters one by one
			else {
				roles.add("a");
				a = "";
			}
		}

		fr.close();
	}

public	ArrayList<String> getRole() {
		return roles;
	}
}
