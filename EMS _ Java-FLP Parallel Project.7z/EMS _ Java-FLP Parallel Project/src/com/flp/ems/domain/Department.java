package com.flp.ems.domain;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Department {
	static ArrayList<String> dept = new ArrayList<String>();

	public Department() {
		try {
			FileReader fr = new FileReader("Departments.txt");
			char ar[] = new char[500];
			fr.read(ar);
			String a = "";
			for (char c : ar) {
				if (c != '\\') {
					a = a + c;
				} // prints the characters one by one
				else {
					dept.add(a);
					//System.out.println(a);
					a = "";
				}
			}

			fr.close();
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public  ArrayList<String> getDepartment() {
		return dept;
	}

}
