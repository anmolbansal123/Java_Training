package com.flp.ems.dao;

public interface IemployeeDao {
	public void AddEmployee();

	public void ModifyEmployee();

	public void RemoveEmployee();

	public void SearchEmployee();

	public void getAllEmployee();
}
