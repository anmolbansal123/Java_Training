package com.flp.ems.dao;

public class EmployeeDaoImplForList implements IemployeeDao {

	@Override
	public void AddEmployee() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ModifyEmployee() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void RemoveEmployee() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void SearchEmployee() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getAllEmployee() {
		// TODO Auto-generated method stub
		
	}

}
