package com.flp.ems.service;
import java.util.HashMap;

public interface IEmployeeService {
	public void AddEmployee(HashMap hm);

	public void ModifyEmployee(HashMap hm);

	public void RemoveEmployee(HashMap hm);

	public void SearchEmployee(HashMap hm);

	public void getAllEmployee(HashMap hm);
}
