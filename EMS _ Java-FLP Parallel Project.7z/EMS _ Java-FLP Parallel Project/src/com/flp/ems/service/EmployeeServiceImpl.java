package com.flp.ems.service;

import java.util.HashMap;

public class EmployeeServiceImpl  implements IEmployeeService{

	@Override
	public void AddEmployee(HashMap hm) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ModifyEmployee(HashMap hm) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void RemoveEmployee(HashMap hm) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void SearchEmployee(HashMap hm) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getAllEmployee(HashMap hm) {
		// TODO Auto-generated method stub
		
	}

}
