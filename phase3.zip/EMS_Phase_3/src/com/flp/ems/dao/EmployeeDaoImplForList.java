package com.flp.ems.dao;

import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.flp.ems.domain.Employee;
import com.flp.ems.util.DBConnector;

public class EmployeeDaoImplForList implements IemployeeDao {

	@Override
	public boolean AddEmployee(Employee e) throws SQLException {
		// TODO Auto-generated method stub
		// emp.add(e);

		String selectDeptQuery = "Select DepartmentId from `test`.`department` where Name = ?";
		String selectRoleQuery = "Select RoleID from `test`.`role` where Name = ?";
		String selectProjQuery = "Select ProjectID from `test`.`project` where Name = ?";

		String insertQuery = "INSERT INTO `test`.`employee` (`Name`, `kin_id`, `email_id`, `PhoneNo`, `DOB`, `DOJ`, `Address`, `DeptID`, `PID`, `RID`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (PreparedStatement stmt = DBConnector.dbConnection
				.prepareStatement(insertQuery);
				PreparedStatement stmt1 = DBConnector.dbConnection
						.prepareStatement(selectDeptQuery);
				PreparedStatement stmt2 = DBConnector.dbConnection
						.prepareStatement(selectRoleQuery);
				PreparedStatement stmt3 = DBConnector.dbConnection
						.prepareStatement(selectProjQuery)) {

			stmt1.setString(1, e.getDepartment());
			stmt2.setString(1, e.getRole());
			stmt3.setString(1, e.getProject());

			ResultSet result1 = stmt1.executeQuery();
			result1.next();

			int deptid = result1.getInt(1);

			ResultSet result2 = stmt2.executeQuery();
			result2.next();

			int roleid = result2.getInt(1);

			ResultSet result3 = stmt3.executeQuery();
			result3.next();

			int projid = result3.getInt(1);

			stmt.setString(1, e.getName());
			stmt.setString(2, e.getKin_id());
			stmt.setString(3, e.getEmail_id());
			stmt.setLong(4, e.getPhone_no());
			stmt.setDate(5, e.getDOB());
			stmt.setDate(6, e.getDOJ());
			stmt.setString(7, e.getAddress());
			stmt.setInt(8, deptid);
			stmt.setInt(9, projid);
			stmt.setInt(10, roleid);

			boolean flag = stmt.execute();

			return flag;

		}

	}

	@Override
	public boolean ModifyEmployee(Employee e) throws SQLException {
		// TODO Auto-generated method stub

		String kin_id = e.getKin_id();

		String query = "UPDATE `test`.`employee` SET `PhoneNo`= ?, `DOB`= ?, `Address`= ?, `DeptID`= ?, `PID`= ?, `RID`= ? WHERE `kin_id`= ?";
		String selectDeptQuery = "Select DepartmentId from `test`.`department` where Name = ?";
		String selectRoleQuery = "Select RoleID from `test`.`role` where Name = ?";
		String selectProjQuery = "Select ProjectID from `test`.`project` where Name = ?";

		try (PreparedStatement stmt = DBConnector.dbConnection
				.prepareStatement(query);
				PreparedStatement stmt1 = DBConnector.dbConnection
						.prepareStatement(selectDeptQuery);
				PreparedStatement stmt2 = DBConnector.dbConnection
						.prepareStatement(selectRoleQuery);
				PreparedStatement stmt3 = DBConnector.dbConnection
						.prepareStatement(selectProjQuery)) {

			stmt1.setString(1, e.getDepartment());
			stmt2.setString(1, e.getRole());
			stmt3.setString(1, e.getProject());

			ResultSet result1 = stmt1.executeQuery();
			ResultSet result2 = stmt2.executeQuery();
			ResultSet result3 = stmt3.executeQuery();

			result1.next();
			result2.next();
			result3.next();

			int dept = result1.getInt(1);
			int role = result2.getInt(1);
			int proj = result3.getInt(1);

			stmt.setLong(1, e.getPhone_no());
			stmt.setDate(2, e.getDOB());
			stmt.setString(3, e.getAddress());
			stmt.setInt(4, dept);
			stmt.setInt(5, proj);
			stmt.setInt(6, role);
			stmt.setString(7, e.getKin_id());
			boolean flag = stmt.execute();

			return flag;
		}

	}

	@Override
	public boolean RemoveEmployee(String kin_id) throws SQLException {
		// TODO Auto-generated method stub
		String query1 = "Select * FROM `test`.`employee` WHERE `kin_id`= ?";
		try (PreparedStatement stmt1 = DBConnector.dbConnection
				.prepareStatement(query1)) {
			stmt1.setString(1, kin_id);
			ResultSet result = stmt1.executeQuery();

			if (result.next()) {
				String query = "DELETE FROM `test`.`employee` WHERE `kin_id`= ?";
				try (PreparedStatement stmt = DBConnector.dbConnection
						.prepareStatement(query)) {
					stmt.setString(1, kin_id);
					boolean flag = stmt.execute();
					return flag;
				}
			}

			else {
				return true;
			}

		}

	}

	@Override
	public Employee SearchEmployee(String kin_id) throws SQLException {
		// TODO Auto-generated method stub

		try (Statement stmt = DBConnector.dbConnection.createStatement();
				Statement stmt1 = DBConnector.dbConnection.createStatement();
				Statement stmt2 = DBConnector.dbConnection.createStatement();
				Statement stmt3 = DBConnector.dbConnection.createStatement()) {

			String query = "Select * from employee WHERE kin_id = " + kin_id;

			ResultSet result;

			result = stmt.executeQuery(query);

			if (result.next()) {

				String selectDeptQuery = "Select Name from `test`.`department` where DepartmentId = "
						+ result.getInt(9);
				String selectRoleQuery = "Select Name from `test`.`role` where RoleID = "
						+ result.getInt(11);
				String selectProjQuery = "Select Name from `test`.`project` where ProjectID = "
						+ result.getInt(10);

				ResultSet result1 = stmt1.executeQuery(selectDeptQuery);
				ResultSet result2 = stmt2.executeQuery(selectRoleQuery);
				ResultSet result3 = stmt3.executeQuery(selectProjQuery);

				result1.next();
				result2.next();
				result3.next();

				String dept = result1.getString(1);
				String role = result2.getString(1);
				String project = result3.getString(1);

				Employee temp = new Employee(result.getString(2),
						result.getLong(5), result.getString(8),
						result.getDate(6), result.getDate(7), dept, role,
						project);

				return temp;
			} else {
				return null;
			}
		}

	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws SQLException {
		// TODO Auto-generated method stub
		String query = "Select * FROM employee";
		ArrayList<Employee> emp = new ArrayList<Employee>();
	
		Statement stmt = DBConnector.dbConnection.createStatement();

		ResultSet result = stmt.executeQuery(query);

		while (result.next()) {

			String Name = result.getString(2);
			String kin_id = result.getString(3);
			String email_id = result.getString(4);
			long phone_no = result.getLong(5);
			String address = result.getString(8);
			Date DOB = result.getDate(6);
			Date DOJ = result.getDate(7);

			int dept = result.getInt(9);
			int role = result.getInt(11);
			int proj = result.getInt(10);

			try (Statement stmt1 = DBConnector.dbConnection.createStatement();
					Statement stmt2 = DBConnector.dbConnection
							.createStatement();
					Statement stmt3 = DBConnector.dbConnection
							.createStatement()) {

				String selectDeptQuery = "Select Name from `test`.`department` where DepartmentId = "
						+ dept;
				String selectRoleQuery = "Select Name from `test`.`role` where RoleID = "
						+ role;
				String selectProjQuery = "Select Name from `test`.`project` where ProjectID = "
						+ proj;

				ResultSet result1 = stmt1.executeQuery(selectDeptQuery);
				ResultSet result2 = stmt2.executeQuery(selectRoleQuery);
				ResultSet result3 = stmt3.executeQuery(selectProjQuery);

				result1.next();
				result2.next();
				result3.next();

				String Department = result1.getString(1);
				String Role = result2.getString(1);
				String Project = result3.getString(1);

				Employee e = new Employee(Name, phone_no, address, DOB, DOJ,
						Department, Role, Project);

				e.setKin_id(kin_id);
				e.setEmail_id(email_id);

				emp.add(e);

			}

		}

		return emp;

	}

}
