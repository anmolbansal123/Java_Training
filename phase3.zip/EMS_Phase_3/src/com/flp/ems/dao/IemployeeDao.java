package com.flp.ems.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.flp.ems.domain.Employee;

public interface IemployeeDao {
	public boolean AddEmployee(Employee e) throws SQLException;

	public boolean ModifyEmployee(Employee e) throws SQLException;

	public boolean RemoveEmployee(String kin_id)throws SQLException;

	public Employee SearchEmployee(String kin_id) throws SQLException;

	public ArrayList<Employee> getAllEmployee()throws SQLException;
}
