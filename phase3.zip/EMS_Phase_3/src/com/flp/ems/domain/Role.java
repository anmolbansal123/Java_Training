package com.flp.ems.domain;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.flp.ems.util.DBConnector;

public class Role {

	static ArrayList<String> role = new ArrayList<String>();

	public static ArrayList<String> getRole() throws IOException, SQLException {

		try (Statement stmt = DBConnector.dbConnection.createStatement()) {

			String query = "Select * from role";

			ResultSet result;

			result = stmt.executeQuery(query);

			if (result.next()) {
				int index = 0;
				// System.out.println(index);

				if (role.isEmpty()) {
					do {
						role.add(index, result.getString(2));
						index++;
					} while (result.next());
				} else {
					while (!role.isEmpty()) {
						role.remove(0);
					}
					do {
						role.add(index, result.getString(2));
						index++;
					} while (result.next());
				}
				return role;
			}

			else {
				return null;
			}
		}

	}

}
