package com.flp.ems.domain;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.flp.ems.util.DBConnector;

public class Project {

	static ArrayList<String> project = new ArrayList<String>();

	public static ArrayList<String> getProject(String dept) throws IOException,
			SQLException {

		String query = "SELECT project.Name FROM project INNER JOIN department ON project.DepartmentId=department.DepartmentId and department.Name = ?";

		try (PreparedStatement stmt = DBConnector.dbConnection
				.prepareStatement(query)) {

			stmt.setString(1, dept);

			ResultSet result;
			result = stmt.executeQuery();

			if (result.next()) {
				int index = 0;
				// System.out.println(index);

				if (project.isEmpty()) {
					do {
						project.add(index, result.getString(1));
						index++;
					} while (result.next());
				} else {
					while (!project.isEmpty()) {
						project.remove(0);
					}
					do {
						project.add(index, result.getString(1));
						index++;
					} while (result.next());
				}
				return project;
			}

			else {
				return null;
			}
		}

	}

}
