package com.flp.ems.domain;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.flp.ems.util.DBConnector;

public class Employee implements Cloneable {

	private String Name;
	private String kin_id;
	private String email_id;
	private long phone_no;
	private String address;
	private Date DOB;
	private Date DOJ;
	private String Department;
	private String Role;
	private String Project;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	};

	@Override
	public boolean equals(Object o) {
		if (this.kin_id == ((Employee) o).kin_id
				&& this.email_id == ((Employee) o).email_id) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		long n = phone_no;
		int t = (int) n % 10;
		return t;

	}

	public Employee(String name, long phone_no, String address, Date dOB,
			Date dOJ, String department, String role, String project)
			throws SQLException {

		Name = name;
		this.phone_no = phone_no;
		this.address = address;
		DOB = dOB;
		DOJ = dOJ;
		Department = department;
		Role = role;
		Project = project;

	}

	public void generate_kin_id() throws SQLException {
		int id = 0;
		try (Statement stmt = DBConnector.dbConnection.createStatement()) {

			String query = "Select kin_id from employee";

			ResultSet result;

			result = stmt.executeQuery(query);
			if (result.next()) {
				result.last();
				id = (result.getInt(1)) + 1;
			} else {
				id = 1001;
			}

		}

		this.kin_id = "" + id;

	}

	public void generate_email_id() {
		this.email_id = this.kin_id + Name + "@" + Department + ".barclays.com";
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getKin_id() {
		return kin_id;
	}

	public void setKin_id(String kin_id) {
		this.kin_id = kin_id;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public long getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public Date getDOJ() {
		return DOJ;
	}

	public void setDOJ(Date dOJ) {
		DOJ = dOJ;
	}

	public String getDepartment() {
		return Department;
	}

	public void setDepartment(String department) {
		Department = department;
	}

	public String getRole() {
		return Role;
	}

	public void setRole(String role) {
		Role = role;
	}

	public String getProject() {
		return Project;
	}

	public void setProject(String project) {
		Project = project;
	}

}
