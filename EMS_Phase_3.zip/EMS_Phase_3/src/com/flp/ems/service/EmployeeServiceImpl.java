package com.flp.ems.service;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.flp.ems.dao.EmployeeDaoImplForList;
import com.flp.ems.domain.Employee;

public class EmployeeServiceImpl implements IEmployeeService {
	EmployeeDaoImplForList EDI = new EmployeeDaoImplForList();

	@Override
	public boolean AddEmployee(HashMap<String, String> hm) throws SQLException {
		// TODO Auto-generated method stub

		String name = hm.get("Name");
		long phone_no = Long.parseLong(hm.get("Mobile"));
		String address = hm.get("Address");
		String DOB = hm.get("DOB");
		String DOJ = hm.get("DOJ");
		String Department = hm.get("Department");
		String Role = hm.get("Role");
		String Project = hm.get("Project");
		System.out.println(Project);
		Date dob = Date.valueOf(DOB);
		Date doj = Date.valueOf(DOJ);

		Employee e = new Employee(name, phone_no, address, dob, doj,
				Department, Role, Project);

		e.generate_kin_id();
		e.generate_email_id();

		boolean flag = false;
		try {
			flag = EDI.AddEmployee(e);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return flag;
	}

	@Override
	public boolean ModifyEmployee(HashMap<String, String> hm)
			throws SQLException {

		// TODO Auto-generated method stub

		Employee e = EDI.SearchEmployee(hm.get("kin_id"));

		if (hm.containsKey("Address")) {
			e.setAddress(hm.get("Address"));
		}
		if (hm.containsKey("Department")) {
			e.setDepartment(hm.get("Department"));
		}
		if (hm.containsKey("Role")) {
			e.setRole(hm.get("Role"));
		}
		if (hm.containsKey("Mobile")) {
			e.setPhone_no(Long.parseLong(hm.get("Mobile")));
		}
		if (hm.containsKey("DOB")) {
			e.setDOB(Date.valueOf(hm.get("DOB")));
		}

		e.setKin_id(hm.get("kin_id"));

		boolean flag = EDI.ModifyEmployee(e);
		return flag;

	}

	@Override
	public boolean RemoveEmployee(HashMap<String, String> hm)
			throws SQLException {
		// TODO Auto-generated method stub
		String kin_id = hm.get("kin_id");
		boolean flag = EDI.RemoveEmployee(kin_id);
		return flag;
	}

	@Override
	public HashMap<String, String> SearchEmployee(HashMap<String, String> hm)
			throws SQLException {
		// TODO Auto-generated method stub

		String kin_id = hm.get("kin_id");

		Employee e = EDI.SearchEmployee(kin_id);

		HashMap<String, String> hm1 = new HashMap<String, String>();

		if (e != null) {

			hm1.put("flag", "true");
			// hm1.put("kin_id", e.getKin_id());
			hm1.put("Name", e.getName());
			hm1.put("Department", e.getDepartment());
			hm1.put("Role", e.getRole());
			// hm1.put("email_id", e.getEmail_id());
			hm1.put("Mobile", ("" + e.getPhone_no()));
			hm1.put("Project", e.getProject());
			return hm1;

		} else {

			hm1.put("flag", "false");
			return hm1;
		}

	}

	@Override
	public ArrayList<HashMap<String, String>> getAllEmployee()
			throws SQLException {
		// TODO Auto-generated method stub

		ArrayList<Employee> e = EDI.getAllEmployee();

		if (e.isEmpty()) {
			return null;
		}

		else {

			ArrayList<HashMap<String, String>> einfo = new ArrayList<HashMap<String, String>>();

			for (Employee e1 : e) {

				HashMap<String, String> hm = new HashMap<String, String>();

				hm.put("kin_id", e1.getKin_id());
				hm.put("Name", e1.getName());
				hm.put("Department", e1.getDepartment());
				hm.put("Role", e1.getRole());
				hm.put("email_id", e1.getEmail_id());
				hm.put("Mobile", ("" + e1.getPhone_no()));
				hm.put("Project", e1.getProject());
				einfo.add(hm);

			}

			return einfo;
		}

	}

}
