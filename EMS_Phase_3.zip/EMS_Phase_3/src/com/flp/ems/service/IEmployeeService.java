package com.flp.ems.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public interface IEmployeeService {
	public boolean AddEmployee (HashMap<String, String> hm) throws SQLException;

	public boolean ModifyEmployee(HashMap<String, String> hm)throws SQLException;

	public boolean RemoveEmployee(HashMap<String, String> hm)throws SQLException;

	public HashMap<String, String> SearchEmployee(HashMap<String, String> hm)throws SQLException;

	public ArrayList<HashMap<String, String>> getAllEmployee()throws SQLException;
}
