package com.flp.ems.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnector {
	public static Properties props;
	public static FileInputStream fin;
	public static String url;
	public static Connection dbConnection;

	public static int DBConnection() throws IOException, SQLException {
		/*
		 * props = new Properties(); fin = new
		 * FileInputStream("dbDetails.properties"); props.load(fin); url =
		 * props.getProperty("jdbc.url"); //dbConnection =
		 * DriverManager.getConnection(url, "root", "forgot12");
		 */
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String url = "jdbc:mysql://localhost:3306/test";
		dbConnection = DriverManager.getConnection(url);
		if (dbConnection != null) {
			return 1;
		} else {
			return 0;
		}
	}
}
