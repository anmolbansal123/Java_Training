package com.flp.ems.domain;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.flp.ems.util.DBConnector;

public class Department {

	static ArrayList<String> dept = new ArrayList<String>();

	public static ArrayList<String> getDepartment() throws IOException,
			SQLException {

		try (Statement stmt = DBConnector.dbConnection.createStatement()) {

			String query = "Select * from department";

			ResultSet result;

			result = stmt.executeQuery(query);

			if (result.next()) {
				int index = 0;
				// System.out.println(index);

				if (dept.isEmpty()) {
					do {
						dept.add(index, result.getString(2));
						index++;
					} while (result.next());
				} else {
					while (!dept.isEmpty()) {
						dept.remove(0);
					}
					do {
						dept.add(index, result.getString(2));
						index++;
					} while (result.next());
				}
				return dept;
			}

			else {
				return null;
			}
		}

	}

}
