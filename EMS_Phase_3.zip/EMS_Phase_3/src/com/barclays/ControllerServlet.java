package com.barclays;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.dao.EmployeeDaoImplForList;
import com.flp.ems.domain.Department;
import com.flp.ems.domain.Project;
import com.flp.ems.domain.Role;
import com.flp.ems.service.EmployeeServiceImpl;
import com.flp.ems.util.DBConnector;

/**
 * Servlet implementation class ControllerServlet
 */
@WebServlet("/controller")
public class ControllerServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final String ACTION_KEY = "action";
	private static final String ADD_EMPLOYEE = "addEmployee";
	private static final String SAVE_EMPLOYEE = "saveEmployee";
	private static final String MODIFY_EMPLOYEE = "modifyEmployee";
	private static final String DELETE_EMPLOYEE = "deleteEmployee";
	private static final String SEARCH_EMPLOYEE = "searchEmployee";
	private static final String VIEW_EMPLOYEE = "viewEmployee";

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			processRequest(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			processRequest(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws IOException, SQLException {

		DBConnector.DBConnection();
		String actionName = request.getParameter(ACTION_KEY);
		String destinationPage = null;

		if (actionName.equals(ADD_EMPLOYEE)) {

			ArrayList<String> dept = Department.getDepartment();
			ArrayList<String> role = Role.getRole();
			
			
			ArrayList<ArrayList<String>> proj = null;
			
			
			for(int i=0;i<dept.size();i++)
			{
				proj.add(Project.getProject(dept.get(i)));
			}
			
			
			
			request.setAttribute("deptList", dept);
			request.setAttribute("roleList", role);
			request.setAttribute("projList", proj);
			

			destinationPage = "addEmp.jsp";

		}

		else if (actionName.equals(SAVE_EMPLOYEE)) {

		}

		else if (actionName.equals(MODIFY_EMPLOYEE)) {

		}

		else if (actionName.equals(DELETE_EMPLOYEE)) {

		}

		else if (actionName.equals(SEARCH_EMPLOYEE)) {

		}

		else if (actionName.equals(VIEW_EMPLOYEE)) {

			EmployeeServiceImpl ESI = new EmployeeServiceImpl();

			try {

				ArrayList<HashMap<String, String>> ll = ESI.getAllEmployee();
				request.setAttribute("empList", ll);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			destinationPage = "viewEmp.jsp";
		}

		RequestDispatcher rd = request.getRequestDispatcher(destinationPage);

		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
