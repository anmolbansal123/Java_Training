package com.flp.ems.dao;

import java.util.ArrayList;

import com.flp.ems.domain.Employee;

public class EmployeeDaoImplForList implements IemployeeDao {

	ArrayList<Employee> emp = new ArrayList<Employee>();

	@Override
	public void AddEmployee(Employee e) {
		// TODO Auto-generated method stub
		emp.add(e);

	}

	@Override
	public void ModifyEmployee(Employee e) {
		// TODO Auto-generated method stub
		String kin_id = e.getKin_id();
		for (Employee e1 : emp) {
			if ((e1.getKin_id()).equals(kin_id)) {
				e1.setAddress(e.getAddress());
				e1.setDepartment(e.getDepartment());
				e1.setDOB(e.getDOB());
				e1.setPhone_no(e.getPhone_no());
				e1.setRole(e.getRole());
			}
		}
	}

	@Override
	public void RemoveEmployee(String kin_id) {
		// TODO Auto-generated method stub
		for (Employee e : emp) {
			if ((e.getKin_id()).equals(kin_id)) {

				emp.remove(e);

				break;
			}
		}

	}

	@Override
	public Employee SearchEmployee(String kin_id) {
		// TODO Auto-generated method stub
		for (Employee e : emp) {
			if ((e.getKin_id()).equals(kin_id)) {
				try {
					return (Employee) (e.clone());
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		}
		return null;
	}

	@Override
	public ArrayList<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return emp;
	}

}
