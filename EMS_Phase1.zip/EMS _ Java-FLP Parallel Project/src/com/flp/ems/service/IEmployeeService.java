package com.flp.ems.service;
import java.util.ArrayList;
import java.util.HashMap;

public interface IEmployeeService {
	public void AddEmployee(HashMap<String,String> hm);

	public void ModifyEmployee(HashMap<String,String> hm);

	public void RemoveEmployee(HashMap<String,String> hm);

	public HashMap<String,String> SearchEmployee(HashMap<String,String> hm);

	public ArrayList<HashMap<String,String>> getAllEmployee();
}
